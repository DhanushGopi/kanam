/*let getClimate = () => {
    switch (1243) {
        case (1003, 1006):
            return ("cloud");
        case (1243):
            console.log("Cloud Snowing");
            return ("cloudy_snowing");
        case (1009, 1135, 1147):
            return ("foggy");
        case (1237):
            return ("mode_dual");
        case (1300):
            return ("mist");
        case (1186, 1189, 1201):
            return ("rainy");
        case (1192, 1195):
            return ("rainy_heavy");
        case (1063, 1072, 1150, 1153, 1168, 1171, 1180, 1183, 1198, 1249):
            return ("rainy_light");
        case (1069, 1204, 1207, 1252, 1261):
            return ("rainy_snow");
        case (1264):
            return ("rainy_snowing");
        case (1066, 1114, 1210, 1213, 1216, 1219, 1222, 1240, 1255):
            return ("snowing");
        case (1117, 1225, 1258):
            return ("snowing_heavy");
        case (1000):
            return ("sunny");
        case (1087, 1273, 1276, 1279, 1282):
            return ("thunderstorm");
        case (1246):
            return ("torando");
        default:
            return ("error");
    }
}

*/



/*const getClimate = (val) => {
    if (val in [1063, 1072, 1150, 1153, 1168, 1171, 1180, 1183, 1198, 1249]) {
        console.log("The Value is");
    } else if (val in [1066, 1114, 1210, 1213, 1216, 1219, 1222, 1240, 1255]) {
        console.log("The else if");
    } else {
        console.log("The error");
    }

}
getClimate(1210);*/
const getClimate = (val) => {
    let array = [
        [1003, 1006], //cloud
        [1243], //cloudy_snowing
        [1009, 1135, 1147], //foggy
        [1237], //mode_dual
        [1300], //mist
        [1186, 1189, 1201], //rainy
        [1192, 1195], // rainy_heavy
        [1063, 1072, 1150, 1153, 1168, 1171, 1180, 1183, 1198, 1249], //rainy_light
        [1069, 1204, 1207, 1252, 1261, 1264], //rainy_snow
        [1066, 1114, 1210, 1213, 1216, 1219, 1222, 1240, 1255], //snowing
        [1117, 1225, 1258], //snowing_heavy
        [1000], //sunny
        [1087, 1273, 1276, 1279, 1282], //thunderstorm
        [1246]//torando
    ];

    console.log("The array length", array.length);

    for (let i = 0; i <= (array.length - 1); i++) {
        //console.log(array[i]);
        for (let j = 0; j <= (array[i].length - 1); j++) {
            //console.log("The array row ", i, " the array value ", j, " the accessed value ", array[i][j]);
            if (val == array[i][j]) {
                switch (i) {
                    case 0:
                        return ("cloud");
                    case 1:
                        return ("cloudy_snowing");
                    case 2:
                        return ('foggy');
                    case 3:
                        return ('mode_dual');
                    case 4:
                        return ('mist');
                    case 5:
                        return ('rainy');
                    case 6:
                        return ('rainy_heavy');
                    case 7:
                        return ('rainy_light');
                    case 8:
                        return ('rainy_snow');
                    case 9:
                        return ('snowing');
                    case 10:
                        return ('snowing_heavy');
                    case 11:
                        return ('sunny');
                    case 12:
                        return ('thunderstorm');
                    case 13:
                        return ('torando');
                    default:
                        console.log("error");
                        return "error"
                }
            }
        }

    }
}

getClimate(1216)
