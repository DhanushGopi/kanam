import { useSelector } from "react-redux"

export default function Winddirection() {

    const showWeatherdata = useSelector((state) => state.weatherdata);

    return (<div className="winddirection">
        <p className="dirval">{showWeatherdata.currentwinddirection}</p>
        <div className="diricon">
            <span class="material-symbols-outlined icon icon-small">explore</span>
            <p className="dirlabel">Wind Direction</p>
        </div>

    </div>)
}