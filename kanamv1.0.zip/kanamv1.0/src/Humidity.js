import { useSelector } from "react-redux"

export default function Humidity() {
    const showWeatherdata = useSelector((state) => state.weatherdata);
    return (<div className="humidity">
        <span class="material-symbols-outlined icon icon-small icon-med">humidity_percentage</span>
        <p className="humlabel">Humidity</p>
        <p className="humval">{showWeatherdata.currenthumidity}</p>

    </div>)
}