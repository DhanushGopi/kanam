import { useSelector } from "react-redux";

export default function Windspeed() {

    const showWeatherdata = useSelector((state) => state.weatherdata);

    return (<div className="winddirection windspeeed">
        <p className="dirval spdval">{showWeatherdata.currentwindspeed}</p>
        <div className="diricon spdicon">
            <span class="material-symbols-outlined icon icon-small">air</span>
            <p className="dirlabel spdlabel">Wind Speed</p>
        </div>

    </div>)
}