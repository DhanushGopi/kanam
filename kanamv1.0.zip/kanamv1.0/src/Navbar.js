import { NavLink } from "react-router-dom";

export default function Navbar() {
    return (
        <div className="Navbar">
            <NavLink to='/Home'>Home</NavLink>
            <NavLink to='/'>Weather</NavLink>
        </div>
    )
}