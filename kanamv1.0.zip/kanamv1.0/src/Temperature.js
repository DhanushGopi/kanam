import { useSelector } from "react-redux"

export default function Temperature() {

    const showWeatherdata = useSelector((state) => state.weatherdata);

    const showCelsius = () => {
        document.querySelector(".celbtn").classList.add("activebtn");
        document.querySelector(".fahbtn").classList.remove("activebtn");
        document.querySelector(".tempcel").classList.remove("hidetemp");
        document.querySelector(".tempfah").classList.add("hidetemp");
    }

    const showFahrenheit = () => {
        document.querySelector(".celbtn").classList.remove("activebtn");
        document.querySelector(".fahbtn").classList.add("activebtn");
        document.querySelector(".tempcel").classList.add("hidetemp");
        document.querySelector(".tempfah").classList.remove("hidetemp");
    }

    return (
        <div className="temp">
            <div className="tempbtns hidetemp">
                <button className="tempbtn celbtn activebtn" onClick={showCelsius}>Celsius</button>
                <button className="tempbtn fahbtn " onClick={showFahrenheit}>Fahrenheit</button>
            </div>
            <div className="tempvals">
                <p className="tempval tempcel ">{showWeatherdata.currentcelsius}</p>
                <p className="tempval tempfah hidetemp">{showWeatherdata.currentfahrenheit}</p>
            </div>
            <div className="temploc">
                <p className="loclabel1 cityname">
                    {showWeatherdata.cityname}</p>
                <p className="loclabel2 countryname">
                    <span class="material-symbols-outlined icon icon-small">location_on</span>
                    {showWeatherdata.countryname}</p>
            </div>
        </div>
    )
}