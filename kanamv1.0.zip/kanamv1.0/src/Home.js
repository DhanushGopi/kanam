import Navbar from "./Navbar";
import { useSelector } from "react-redux";

export default function Home() {

    const showWeatherdata = useSelector((state) => state.weatherdata);
    return (
        <div>
            <Navbar />
            <h1>Home</h1>
            <h2>{showWeatherdata.countryname}</h2>
            <h2>{showWeatherdata.cityname}</h2>
            <h2>{showWeatherdata.currentcelsius}</h2>
            <h2>{showWeatherdata.currentwindspeed}</h2>

        </div>
    )
}