import { configureStore } from "@reduxjs/toolkit";


const getWeatherdata = (state = {}, action) => {
    switch (action.type) {
        case "weatherdet":
            return action.data;
        default:
            return false;
    }
}


export const weatherstore = configureStore({
    reducer: {
        "weatherdata": getWeatherdata
    }
})