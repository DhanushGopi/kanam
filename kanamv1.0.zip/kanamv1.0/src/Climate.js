import { useSelector } from "react-redux"
import { NavLink } from "react-router-dom";

export default function Climate() {

    const showWeatherdata = useSelector((state) => state.weatherdata);

    const getClimate = (val) => {
        let array = [
            [1003, 1006], //cloud
            [1243], //cloudy_snowing
            [1009, 1135, 1147], //foggy
            [1237], //mode_dual
            [1030], //mist
            [1186, 1189, 1201], //rainy
            [1192, 1195], // rainy_heavy
            [1063, 1072, 1150, 1153, 1168, 1171, 1180, 1183, 1198, 1249], //rainy_light
            [1069, 1204, 1207, 1252, 1261, 1264], //rainy_snow
            [1066, 1114, 1210, 1213, 1216, 1219, 1222, 1240, 1255], //snowing
            [1117, 1225, 1258], //snowing_heavy
            [1000], //sunny
            [1087, 1273, 1276, 1279, 1282], //thunderstorm
            [1246]//torando
        ];

        console.log("The array length", array.length);

        for (let i = 0; i <= (array.length - 1); i++) {
            //console.log(array[i]);
            for (let j = 0; j <= (array[i].length - 1); j++) {
                //console.log("The array row ", i, " the array value ", j, " the accessed value ", array[i][j]);
                if (val == array[i][j]) {
                    switch (i) {
                        case 0:
                            document.querySelector('.climate').classList.add('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ("cloud");
                        case 1:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.add('snowing');
                            return ("cloudy_snowing");
                        case 2:
                            document.querySelector('.climate').classList.add('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('foggy');
                        case 3:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.add('snowing');
                            return ('mode_dual');
                        case 4:
                            document.querySelector('.climate').classList.add('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('mist');
                        case 5:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.add('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('rainy');
                        case 6:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.add('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('rainy_heavy');
                        case 7:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.add('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('rainy_light');
                        case 8:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.add('snowing');
                            return ('rainy_snow');
                        case 9:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.add('snowing');
                            return ('snowing');
                        case 10:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.add('snowing');
                            return ('snowing_heavy');
                        case 11:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.add('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('sunny');
                        case 12:
                            document.querySelector('.climate').classList.remove('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.add('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('thunderstorm');
                        case 13:
                            document.querySelector('.climate').classList.add('mist');
                            document.querySelector('.climate').classList.remove('sunny');
                            document.querySelector('.climate').classList.remove('thuderstorm');
                            document.querySelector('.climate').classList.remove('rainy');
                            document.querySelector('.climate').classList.remove('snowing');
                            return ('torando');
                        default:
                            console.log("error");
                            return "error";
                    }
                }
            }

        }
    }
    return (

        <div className="climate">
            <p className="loclabel">{showWeatherdata.weathername}</p>
            <span class="material-symbols-outlined icon">
                {getClimate(showWeatherdata.weathercode)}
            </span>
        </div>

    )
}