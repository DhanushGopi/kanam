
import Header from "./Header";
import Temperature from "./Temperature";
import Climate from "./Climate";
import Winddirection from "./Winddirection";
import Windspeed from "./Windspeed";
import Humidity from "./Humidity";
import Footer from "./Footer";

export default function Weather() {
    return (
        <div className="weather">
            <Header />
            <div className="main">
                <Temperature />
                <div className="mainleft">
                    <Climate />
                    <div className="mainleft-btm">
                        <div className="mainleft-btmone">
                            <Winddirection />
                            <Windspeed />
                        </div>
                        <Humidity />
                    </div>
                </div>
            </div>
            <Footer />
        </div >
    )
}