export default function Footer() {
    return (
        <div className="footer">
            <p className="footerlabel">cooked by</p>
            <a href="https://danzustudio.github.io/" className="danzu"> DANZU</a>
        </div>
    )
}