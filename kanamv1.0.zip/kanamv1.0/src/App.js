import './App.css';
import Home from './Home';
import Weather from './Weather';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Provider } from 'react-redux';
import { weatherstore } from './store/weatherstore';

function App() {

  const weatherappnav = createBrowserRouter([
    {
      path: "/Home",
      element: <Home />
    },
    {
      path: "/",
      element: <Weather />
    },
  ])

  return (<Provider store={weatherstore}>
    <div className="App">
      <RouterProvider router={weatherappnav} />
    </div>
  </Provider>
  );
}

export default App;
