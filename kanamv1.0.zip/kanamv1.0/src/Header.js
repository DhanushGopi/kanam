import { useEffect, useState } from "react"
import { useDispatch } from "react-redux";
export default function Header() {

    const [citytext, setCity] = useState("Chennai");

    const getCitytext = (inputcity) => {
        setCity(inputcity.target.value);
    }
    useEffect(() => { weatherRes() }, [])
    const dispatch = useDispatch();


    async function weatherRes() {
        let weatherapi = await fetch(`http://api.weatherapi.com/v1/current.json?key=a7ccff45181a45128aa141538243108&q=${citytext}&aqi=yes`);
        let weatherapijson = await weatherapi.json();
        let countryname = weatherapijson.location.country;
        let cityname = weatherapijson.location.name;
        let weathername = weatherapijson.current.condition.text;
        let weathercode = weatherapijson.current.condition.code;
        let currentcelsius = weatherapijson.current.temp_c;
        let currentfahrenheit = weatherapijson.current.temp_f;
        let currenthumidity = weatherapijson.current.humidity;
        let currentwinddirection = weatherapijson.current.wind_dir;
        let currentwindspeed = weatherapijson.current.wind_mph;

        console.log(weatherapijson);
        console.log("Country Name: ", countryname);
        console.log("City Name: ", cityname);
        console.log("Present Weather: ", weathername);
        console.log("Present Weather Code: ", weathercode);
        console.log("Present Weather Celsius: ", currentcelsius);
        console.log("Present Weather Fahrenheit: ", currentfahrenheit);
        console.log("Present Weather Humdity: ", currenthumidity);
        console.log("Present Wind Direction: ", currentwinddirection);
        console.log("Present Wind Direction: ", currentwindspeed);

        dispatch(
            {
                type: "weatherdet",
                data: {
                    "countryname": `${countryname}`,
                    "cityname": `${cityname}`,
                    "weathername": `${weathername}`,
                    "weathercode": `${weathercode}`,
                    "currentcelsius": `${currentcelsius} c°`,
                    "currentfahrenheit": `${currentfahrenheit} f°`,
                    "currenthumidity": `${currenthumidity} %`,
                    "currentwinddirection": `${currentwinddirection}°`,
                    "currentwindspeed": `${currentwindspeed}`
                }
            }
        )
        // to show up the temp toggle btn
        document.querySelector(".tempbtns").classList.remove('hidetemp');
    }

    return (
        <div className="header">
            {/*<Navbar />*/}
            <div className="header-inside"><h1 className="brandname"><i>கnam</i></h1>
                <input className="search-bar" type="text" onChange={getCitytext} placeholder="Enter the Location" />
                <input className="search-btn" type="button" onClick={weatherRes} value="Search" /></div>
        </div>
    )
}